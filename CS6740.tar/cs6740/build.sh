#!/bin/bash

# Compile the program
gcc directory.c -o directory -lm

# Set root ownership and permissions (SetUID 4555)
sudo chown root:root directory
sudo chmod 4555 directory
