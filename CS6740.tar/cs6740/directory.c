#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <string.h>
#include <ctype.h>

#define MAX_STR 100
#define MAX_FILE_SIZE 10000
#define PASS_FILE "pass.bin"
#define DATA_FILE "directory.txt"

// Global password storage
char current_password[MAX_STR];

// Function to save password change to the file
void save_password() {
    // Raise privilege to root control
    seteuid(0);
    // Open the file in write mode
    FILE *f = fopen(PASS_FILE, "w");
    // Check to see if the file was found
    if (f) {
        // Save the current_password to the file
        fprintf(f, "%s", current_password);
        // Close the file
        fclose(f);
        // Limit read/write to root only
        chmod(PASS_FILE, 0600);
    }
    // Return privileges to the user level
    seteuid(getuid());
}

// Function to load the current password from the file
void load_password() {
    // Open the file in read mode
    FILE *f = fopen(PASS_FILE, "r");
    // Check to see if the file was found
    if (f) {
        // Save the password in the file to current_password and replace \n with \0
        if (fgets(current_password, MAX_STR, f)) {
            current_password[strcspn(current_password, "\n")] = 0;
        }
        // Close the file
        fclose(f);
    }
}

// Function to change passwords
void change_password() {
    // Get the current password from the user
    char old_pass[MAX_STR];
    printf("Enter current password: ");
    scanf("%s", old_pass);
    // If the password is correct have the user enter a new password
    if (strcmp(old_pass, current_password) == 0) {
        printf("Enter new password: ");
        scanf("%s", current_password);
        // Save the new password
        save_password();
        printf("Password saved.\n");
    } 
    else {
        printf("Validation failed.\n");
    }
}

// Function to view the directory details
void view_directory() {
    // Open the directory file in read mode
    FILE *f = fopen(DATA_FILE, "r");
      
    char line[512];
    // Print a cleanly formatted  header for readability
    printf("\n%-15s %-15s %-20s %-10s %-15s\n", "Last", "First", "Position", "ID", "Phone");
    printf("----------------------------------------------------------------------------\n");
    
    // Seperate each line into the different sections by comma
    while (fgets(line, sizeof(line), f)) {
        // Last name
        char *ln = strtok(line, ",");
        // First name
        char *fn = strtok(NULL, ",");
        // Position
        char *pos = strtok(NULL, ",");
        // ID
        char *id = strtok(NULL, ",");
        // Phone number
        char *ph = strtok(NULL, "\n");
        // Print the line of data with the same formatting as the header
        if (ln && fn && pos && id && ph) {
            printf("%-15s %-15s %-15s %-10s %-15s\n", ln, fn, pos, id, ph);
        }
    }
    fclose(f);
}

// Function to add a new record
void add_record() {
    // Set permissions to root
    seteuid(0);
    // Open file in append mode
    FILE *f = fopen(DATA_FILE, "a");
    
    // Get the user input for the new record and save it to the file
    if (f) {
        char ln[MAX_STR], fn[MAX_STR], pos[MAX_STR], id[7], ph[MAX_STR];
        printf("Last: "); scanf("%s", ln);
        printf("First: "); scanf("%s", fn);
        printf("Position: "); scanf("%s", pos);
        printf("ID: "); scanf("%s", id);
        printf("Phone: "); scanf("%s", ph);
        fprintf(f, "%s,%s,%s,%s,%s\n", ln, fn, pos, id, ph);
        fclose(f);
    }
    // Set permissions back to the current user
    seteuid(getuid());
}

// Function to delete or edit a record
void delete_or_edit_record(int is_edit) {
    char target_id[7];
    // Get the user input for the ID
    printf("Enter the 6-digit ID of the record: ");
    scanf("%s", target_id);
    // Set the permissions to root
    seteuid(0);
    FILE *f = fopen(DATA_FILE, "r");
    
    // Crete a temp file for changes
    FILE *temp = fopen("temp.txt", "w");
    char line[512], original_line[512];
    int found = 0;

    while (fgets(line, sizeof(line), f)) {
        // Break the line up by commas and save the id
        strcpy(original_line, line);
        strtok(line, ","); 
        strtok(NULL, ","); 
        strtok(NULL, ",");
        char *id = strtok(NULL, ",");

        // Search for the user given ID
        if (id && strcmp(id, target_id) == 0) {
            found = 1;
            // If the user selected editing mode request user input to update the found line and save the input to the temp file
            if (is_edit) {
                char ln[MAX_STR], fn[MAX_STR], pos[MAX_STR], ph[MAX_STR];
                printf("New Last: "); scanf("%s", ln);
                printf("New First: "); scanf("%s", fn);
                printf("New Position: "); scanf("%s", pos);
                printf("New Phone: "); scanf("%s", ph);
                fprintf(temp, "%s,%s,%s,%s,%s\n", ln, fn, pos, target_id, ph);
            }
            // If the user selected remove for the line don't append it to the temp file
        } 
        // Copy the other lines to temp to maintain all other unmodified lines
        else {
            fprintf(temp, "%s", original_line);
        }
    }
    // Close the files and save the temp file to the data file
    fclose(f); 
    fclose(temp);
    rename("temp.txt", DATA_FILE);
    chmod(DATA_FILE, 0644);
    // Set the permissions back
    seteuid(getuid());

    if (found) 
        printf("Record updated.\n");
    else 
        printf("ID not found.\n");
}

// Helper function to clear out input
void clear_input() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

// Function to get the user input
int get_menu_choice() {
    int choice;
    // If the user input isn't a number print error
    if (scanf("%d", &choice) != 1) {
        printf("Invalid input. Please enter a number.\n");
        clear_input(); 
        return -1;
    }
    return choice;
}

// Function for user modify menu
void modify_directory() {
    // Get user input for password
    char input_pass[MAX_STR];
    printf("Enter password: ");
    scanf("%s", input_pass);
    // Check input against the saved password
    if (strcmp(input_pass, current_password) != 0) {
        printf("Access Denied.\n");
        return;
    }

    // Display user menu for choice
    int choice = 0;
    while (choice != 4) {
        printf("\n--- Modify Submenu ---\n1. Add Record\n2. Edit Record\n3. Delete Record\n4. Back\nChoice: ");
        choice = get_menu_choice();
        // Add record
        if (choice == 1) 
            add_record();
        // Edit record
        else if (choice == 2) 
            delete_or_edit_record(1);
        // Delete record
        else if (choice == 3) 
            delete_or_edit_record(0);
    }
}

 // Core substitution engine.
 // Encryption: shift = (char - 'a' + key_char - 'a') % 26
 // Decryption: shift = (char - 'a' + (26 - (key_char - 'a'))) % 26
void process_cipher(int encrypt) {
    // Create the needed strings
    char key[MAX_STR];
    char in_file[MAX_STR];
    char out_file[MAX_STR];
    
    // Get the user inputs
    printf("Enter key (a-z): ");
    scanf("%s", key);
    printf("Enter input filename: ");
    scanf("%s", in_file);
    printf("Enter output filename: ");
    scanf("%s", out_file);

    // Open the files
    FILE *fin = fopen(in_file, "r");
    FILE *fout = fopen(out_file, "w");

    // If either file failes to open send an error message and return
    if (!fin || !fout) {
        printf("Error opening files.\n");
        if (fin) fclose(fin);
        return;
    }
    
    // Get the length of the key entered
    int key_len = strlen(key);
    // Initialize the key index to 0 and create a char tracker
    int key_idx = 0;
    int c;
    char base;

    // Iterate through the input file until complete
    while ((c = fgetc(fin)) != EOF) {
        // Check if the char is a letter
        if (isalpha(c)) {
            // If the letter is lower case start at lower case a
            if islower(c)
                base = 'a';
              // Otherwise set to captial A 
            else
                base = 'A';
            // Standardize the current key character to lowercase and calculate its alphabetic position (0-25). 
            // The modulo operator ensures the key rotates back to the start for multi-letter keys.
            int k = tolower(key[key_idx % key_len]) - 'a';
            
            // For decryption, moving back K is moving forward (26 - K)
            if (!encrypt) 
                k = (26 - k) % 26;

            // Calculate the alphabetic index of the new char applying the shift and modulo to wrap
            int res = (c - base + k) % 26;
            // Save the new char to the output file
            fputc(res + base, fout);
            // Increment the index
            key_idx++;
        } 
        // If the char isn't a letter keep it as it is
        else {
            fputc(c, fout); 
        }
    }

    fclose(fin);
    fclose(fout);
    printf("Operation complete. Result saved to %s\n", out_file);
}

// Encryption/decryption menu
void crypto_tool() {
    int choice = 0;
    while (choice != 3) {
        // Display user choices
        printf("\n--- Encryption Tool ---\n1. Encrypt\n2. Decrypt\n3. Main Menu\nChoice: ");
       
        choice = get_menu_choice();
        // Encrypt
        if (choice == 1)
            process_cipher(1);
        // Decrypt
        else if (choice == 2) 
            process_cipher(0);
    }
}

// Standard English letter frequencies (percentages)
const float english_freq[26] = {
    8.2, 1.5, 2.8, 4.3, 13.0, 2.2, 2.0, 6.1, 7.0, 0.15, 0.77, 4.0, 2.4,
    6.7, 7.5, 1.9, 0.095, 6.0, 6.3, 9.1, 2.8, 0.98, 2.4, 0.15, 2.0, 0.074
};

// Calculates the Index of Coincidence
float calculate_ioc(const char *text, int len) {
    // If a text with only 1 letter return 0
    if (len <= 1) 
        return 0.0;

    int counts[26] = {0};
    int total_letters = 0;

    // Iterate through each char of text
    for (int i = 0; i < len; i++) {
        // Check if the char is a letter
        if (isalpha(text[i])) {
            // Increment the letter count getting the letter index 0-26
            counts[toupper(text[i]) - 'A']++;
            // Increment the total letter count
            total_letters++;
        }
    }

    // If there is only 1 letter return 0
    if (total_letters <= 1) 
        return 0.0;

    float ioc = 0.0;
    for (int i = 0; i < 26; i++) {
        // Calculate the number of matching pairs for this letter and add it to the running total
        ioc += counts[i] * (counts[i] - 1);
    }
    // Divide the total matching pairs by the total possible pairs of a letter
    return ioc / (total_letters * (total_letters - 1));
}

// Scores text against English frequencies using Chi-Square (lower is better)
float score_english(const char *text, int len) {
    int counts[26] = {0};
    int total_letters = 0;

    // Iterate through each char of text
    for (int i = 0; i < len; i++) {
        // Check if the char is a letter
        if (isalpha(text[i])) {
            // Increment the letter count getting the leter index 0-26
            counts[toupper(text[i]) - 'A']++;
            // Increment the total leter count
            total_letters++;
        }
    }

    float score = 0.0;
    for (int i = 0; i < 26; i++) {
        // Calculate the expected count for the letter given the standard english frequencies
        float expected = total_letters * (english_freq[i] / 100.0);
        // Calculate the differfence between the actual count and the expected
        float diff = counts[i] - expected;
        if (expected > 0) {
            // Chi-Square calculation to get the score
            score += (diff * diff) / expected;
        }
    }
    return score;
}

// CryptoCracker Core
void crypto_cracker() {
    char filename[MAX_STR];
    // Get the filename as user input
    printf("\nEnter the filename to decrypt: ");
    scanf("%s", filename);
    // Open the file
    FILE *f = fopen(filename, "r");
    if (!f) {
        printf("Error: Could not open file.\n");
        return;
    }
    // Read then close the file
    char buffer[MAX_FILE_SIZE];
    int len = fread(buffer, 1, MAX_FILE_SIZE - 1, f);
    buffer[len] = '\0';
    fclose(f);

    if (len == 0) {
        printf("File is empty.\n");
        return;
    }

    char alpha_only[MAX_FILE_SIZE];
    int alpha_len = 0;
    int letter_counts[26] = {0};
    // Iterate therough all chars in the file
    for (int i = 0; i < len; i++) {
        // Check if the char is a letter
        if (isalpha(buffer[i])) {
            // Create a letter only version of the file
            alpha_only[alpha_len] = toupper(buffer[i]);
            // Increment the letter count by index 0-26
            letter_counts[alpha_only[alpha_len] - 'A']++;
            // Increment the length counter
            alpha_len++;
        }
    }
    // Terminate the letter only 'file'
    alpha_only[alpha_len] = '\0';

    // Calculate Index of Coincidence
    float ioc = calculate_ioc(alpha_only, alpha_len);
    printf("\nIndex of Coincidence: %.4f\n", ioc);

    // Find the most frequent letter
    int max_count = 0;
    char most_frequent_char = 'A';
    for (int i = 0; i < 26; i++) {
        if (letter_counts[i] > max_count) {
            max_count = letter_counts[i];
            most_frequent_char = 'A' + i;
        }
    }

    // Identify the ciphert algorithm
    if (ioc > 0.058) {
        // If the IoC is high and the most common letter is E or T, it's most likely a transposition 
        if (most_frequent_char == 'E' || most_frequent_char == 'T') {
            printf("Cipher Algorithm: Simple Columnar Transposition\n");
            printf("Brute-forcing columns. Please choose the deciphered English option:\n");
           
            // Iterate through every possible column 2-15
            for (int cols = 2; cols <= 15 && cols < alpha_len; cols++) {
                // Print the col number
                printf("Key [%02d]: ", cols);
                // Calculate how many rows the grid needs
                int rows = (alpha_len + cols - 1) / cols;
                // Calculate the remainder of letters in the last row
                int rem = alpha_len % cols;
                if (rem == 0) 
                    rem = cols;
                // Print the first 30 letters or full message if less than 30 letters to the screen
                int snippet_len;
                if (alpha_len < 30)
                    snippet_len = alpha_len;
                else
                    snippet_len = 30;

                for(int i = 0; i < snippet_len; i++) {
                    int c = i % cols;
                    int r = i / cols;
                    int idx;
                    // Adjust the index based on if this is a long or short column
                    if (c < rem)
                        idx = (c * rows + r); 
                    else
                        idx = (rem * rows + (c - rem) * (rows - 1) + r);
                    // Print the letter to the screen if less than the display length
                    if(idx < alpha_len) 
                        printf("%c", alpha_only[idx]);
                }
                printf("...\n");
            }
            
            // Get the user chosen key
            int chosen_key;
            printf("\nEnter the key that produced English (or 0 if none): ");
            scanf("%d", &chosen_key);

            // If a non 0 key was chosen display the entire plaintext
            if (chosen_key > 0) {
                printf("\n--- RECOVERED PLAINTEXT ---\n");
                int rows = (alpha_len + chosen_key - 1) / chosen_key;
                int rem = alpha_len % chosen_key;
                if (rem == 0) 
                    rem = chosen_key;

                for(int i = 0; i < alpha_len; i++) {
                    int c = i % chosen_key;
                    int r = i / chosen_key;
                    int idx;
                    if (c < rem)
                        idx = (c * rows + r); 
                    else
                        idx = (rem * rows + (c - rem) * (rows - 1) + r);
                    if(idx < alpha_len) 
                        printf("%c", alpha_only[idx]);
                }
                printf("\n---------------------------\n");
            } 
            // If 0 was chosen re identify the algorithm as other
            else {
                printf("\nAlgorithm Re-Identified: Other\n");
            }
        } 
        // If the IoC is high, but the most common letter isn't E or T, it is most likely Caesar
        else {
            printf("Cipher Algorithm : Caesar Cipher\n");
            
            int best_shift = 0;
            float best_score = 999999.0;

            // Iterate through all possible shifts
            for (int shift = 0; shift < 26; shift++) {
                char temp[MAX_FILE_SIZE];
                // Shift the text backward by the current amount
                for (int i = 0; i < alpha_len; i++) {
                    temp[i] = ((alpha_only[i] - 'A' - shift + 26) % 26) + 'A';
                }
                temp[alpha_len] = '\0';
                // Get the score
                float score = score_english(temp, alpha_len);

                // Save the best(lowest) score and shift
                if (score < best_score) {
                    best_score = score;
                    best_shift = shift;
                }
            }
            // Print the info
            printf("Recovered Key: %d\n", best_shift);
            printf("\n--- RECOVERED PLAINTEXT ---\n");
            for (int i = 0; i < len; i++) {
                if (isalpha(buffer[i])) {
                    char base = islower(buffer[i]) ? 'a' : 'A';
                    printf("%c", ((buffer[i] - base - best_shift + 26) % 26) + base);
                } 
                else {
                    printf("%c", buffer[i]);
                }
            }
            printf("\n---------------------------\n");
        }
    }
    // Low IoC points to Vigenere
    else if (ioc < 0.055 && ioc > 0.030) {
        printf("Algorithm Identified: Vigenere Cipher\n");
        printf("Brute-forcing key length. Please choose the deciphered English option:\n");

        // iterate through and display options 2-15
        for (int k = 2; k <= 15 && k < alpha_len/2; k++) {
            char recovered_key[MAX_STR] = {0};
            // Treat every k letter as its own cipher column
            for (int col = 0; col < k; col++) {
                int best_shift = 0;
                float best_score = 999999.0;
                // Find the best shift for the current column
                for (int shift = 0; shift < 26; shift++) {
                    char temp_col[MAX_FILE_SIZE];
                    int col_len = 0;
                    for (int i = col; i < alpha_len; i += k) {
                        temp_col[col_len++] = ((alpha_only[i] - 'A' - shift + 26) % 26) + 'A';
                    }
                    float score = score_english(temp_col, col_len);
                    if (score < best_score) {
                        best_score = score;
                        best_shift = shift;
                    }
                }
                // Save the best shift as a letter in the potential key
                recovered_key[col] = best_shift + 'A';
            }
            // Display the option to the user
            printf("KeyLen [%02d] (Key: %-15s): ", k, recovered_key);
            int snippet_len = (alpha_len < 40) ? alpha_len : 40;
            for (int i = 0; i < snippet_len; i++) {
                int shift = recovered_key[i % k] - 'A';
                printf("%c", ((alpha_only[i] - 'A' - shift + 26) % 26) + 'A');
            }
            printf("...\n");
        }
        // Get the user chosen key
        int chosen_key_len;
        printf("\nEnter the key length that produced English (or 0 if none): ");
        scanf("%d", &chosen_key_len);

        // If an option was chosen run the column logic with the chosen key to ge the full deciphered text
        if (chosen_key_len > 0) {
            char final_key[MAX_STR] = {0};
            for (int col = 0; col < chosen_key_len; col++) {
                int best_shift = 0;
                float best_score = 999999.0;
                for (int shift = 0; shift < 26; shift++) {
                    char temp_col[MAX_FILE_SIZE];
                    int col_len = 0;
                    for (int i = col; i < alpha_len; i += chosen_key_len) {
                        temp_col[col_len++] = ((alpha_only[i] - 'A' - shift + 26) % 26) + 'A';
                    }
                    float score = score_english(temp_col, col_len);
                    if (score < best_score) {
                        best_score = score;
                        best_shift = shift;
                    }
                }
                final_key[col] = best_shift + 'A';
            }
            // Print the info
            printf("\nRecovered Key: %s\n", final_key);
            printf("\n--- RECOVERED PLAINTEXT ---\n");
            
            int key_idx = 0;
            for (int i = 0; i < len; i++) {
                if (isalpha(buffer[i])) {
                    char base = islower(buffer[i]) ? 'a' : 'A';
                    int shift = final_key[key_idx % chosen_key_len] - 'A';
                    printf("%c", ((buffer[i] - base - shift + 26) % 26) + base);
                    key_idx++;
                } else {
                    printf("%c", buffer[i]);
                }
            }
            printf("\n---------------------------\n");
        } 
        // If a 0 was entered re-identify the algorithm as other
        else {
            printf("\n[+] Algorithm Re-Identified: Other\n");
        }
    } 
    // If the IoC doesn't fit the standard value for the algorthms assume it is other
    else {
        printf("Algorithm Identified: Other (IoC is unusual)\n");
    }
}

// Function to display menu options
void employee_menu() {
    int choice = 0;
    while (choice != 4) {
        // Display user choises
        printf("\n1. View Directory\n2. Modify Directory\n3. Change Password\n4. Main Menu\nChoice: ");
        choice = get_menu_choice();
        // View directory
        if (choice == 1) 
            view_directory();
        // Modify directory
        else if (choice == 2) 
            modify_directory();
        // Change password
        else if (choice == 3) 
            change_password();
    }
}

int main() {
    // Load the current password
    load_password();

    // Verify that the directory file exists
    FILE *f = fopen(DATA_FILE, "r");
    if (!f) {
        // If the file doesn't exist create it with permissions 644 and root ownership
        f = fopen(DATA_FILE, "w");
        if (f){
            seteuid(0);
            setegid(0);
            chmod(DATA_FILE, 0644);
            chown(DATA_FILE, 0, 0);
            seteuid(getuid());
            setegid(getgid());
        }
    }

    // Set permissions for the current user
    seteuid(getuid()); 

    int choice = 0;
    // Display user initial menu
    while (choice != 4) {
        printf("\nMain Menu\n1. Employee Directory\n2. Encryption/Decryption Tool\n3. Crypto Cracker\n4. Quit\nChoice: "); 
        choice = get_menu_choice();
        // Display menu options
        if (choice == 1) 
            employee_menu();
        else if (choice == 2)
            crypto_tool();
        else if (choice == 3)
            crypto_cracker();
    }
    return 0;
}
